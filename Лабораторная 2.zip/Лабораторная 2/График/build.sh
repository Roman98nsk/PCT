#!/bin/sh

gnuplot ./graph.gp
